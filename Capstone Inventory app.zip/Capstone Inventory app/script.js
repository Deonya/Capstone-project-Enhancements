// Store the last searched results globally
let lastSearchResults = new Map();

// Fetch and display item data based on search
function fetchItemData() {
    const searchInput = document.getElementById("inputData").value.trim().toLowerCase();
    
    if (!searchInput) {
        alert("Please enter at least one item to search for.");
        return;
    }

    // Split input into multiple search terms (comma-separated)
    const searchTerms = searchInput.split(/\s*,\s*/); 

    fetch('http://localhost:3000/items')
        .then(response => response.json())
        .then(data => {
            // Filter items that match any of the search terms
            const filteredData = data.filter(item => searchTerms.includes(item.name.toLowerCase()));

            if (filteredData.length === 0) {
                alert("No matching items found!");
            } else {
                lastSearchResults = new Map(filteredData.map(item => [item.name.toLowerCase(), item])); // Store search results globally
                updateDisplay(Array.from(lastSearchResults.values())); // Display results
            }
        })
        .catch(error => console.error('Error fetching data:', error));
}

// Function to process user input and count word frequencies
function processData() {
    let inputText = document.getElementById("inputData").value;
    let items = inputText.split(/\s+/);
    itemMap.clear();

    // Count occurrences of each item
    items.forEach(item => {
        if (item) {
            let lowerCaseItem = item.toLowerCase();
            itemMap.set(lowerCaseItem, (itemMap.get(lowerCaseItem) || 0) + 1);
        }
    });

    // Fetch existing data before adding/updating
    fetch('http://localhost:3000/items')
        .then(response => response.json())
        .then(existingData => {
            let existingMap = new Map(existingData.map(item => [item.name.toLowerCase(), item]));

            itemMap.forEach((value, key) => {
                if (existingMap.has(key)) {
                    // Update frequency if item already exists
                    let existingItem = existingMap.get(key);
                    updateItemFrequency(existingItem.id, existingItem.frequency + value);
                } else {
                    // Add new item if not found
                    saveItemData(key, value);
                }
            });
        })
        .catch(error => console.error('Error fetching existing data:', error));
}

// Function to add a new item to the database
function saveItemData(item, frequency) {
    fetch('http://localhost:3000/items', {
        method: 'POST',
        body: JSON.stringify({ name: item, frequency: frequency }),
        headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(data => console.log('New item added:', data))
    .catch(error => console.error('Error saving data:', error));
}

// Function to update an existing item's frequency
function updateItemFrequency(itemId, newFrequency) {
    fetch(`http://localhost:3000/items/${itemId}`, {
        method: 'PATCH',
        body: JSON.stringify({ frequency: newFrequency }),
        headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(data => console.log('Item updated:', data))
    .catch(error => console.error('Error updating item:', error));
}

// Merge Sort Algorithm for sorting items
function mergeSort(arr, key, ascending = true) {
    if (arr.length <= 1) return arr;

    const mid = Math.floor(arr.length / 2);
    const left = mergeSort(arr.slice(0, mid), key, ascending);
    const right = mergeSort(arr.slice(mid), key, ascending);

    return merge(left, right, key, ascending);
}

// Merge function
function merge(left, right, key, ascending) {
    let sortedArray = [];
    while (left.length && right.length) {
        let comparison = ascending ? left[0][key] < right[0][key] : left[0][key] > right[0][key];
        sortedArray.push(comparison ? left.shift() : right.shift());
    }
    return [...sortedArray, ...left, ...right];
}

// Function to update sorting selection dynamically
function updateSortOrder() {
    if (lastSearchResults.size > 0) {
        updateDisplay(Array.from(lastSearchResults.values())); // Sort only search results
    } else {
        fetch('http://localhost:3000/items') // Fetch all items if no search results
            .then(response => response.json())
            .then(data => updateDisplay(data))
            .catch(error => console.error('Error fetching data:', error));
    }
}

// Function to display sorted data based on selected sorting option
function updateDisplay(data) {
    const sortOption = document.getElementById("sortOptions").value;
    let sortedData;

    switch (sortOption) {
        case "frequency-desc":
            sortedData = mergeSort(data, "frequency", false);
            break;
        case "frequency-asc":
            sortedData = mergeSort(data, "frequency", true);
            break;
        case "name-asc":
            sortedData = mergeSort(data, "name", true);
            break;
        case "name-desc":
            sortedData = mergeSort(data, "name", false);
            break;
        default:
            sortedData = data;
    }

    displayItemData(sortedData);
}

// Function to display sorted items
function displayItemData(data) {
    let output = "";
    data.forEach(item => output += `${item.name}: ${item.frequency}\n`);
    document.getElementById("frequencyOutput").innerText = output;
}

// Function to display a histogram sorted by selected criteria
function displayHistogram() {
    let dataToSort = lastSearchResults.size > 0 ? Array.from(lastSearchResults.values()) : null;

    if (!dataToSort) {
        fetch('http://localhost:3000/items')
            .then(response => response.json())
            .then(data => sortAndDisplayHistogram(data))
            .catch(error => console.error('Error fetching data:', error));
    } else {
        sortAndDisplayHistogram(dataToSort);
    }
}

// Helper function to sort and display the histogram
function sortAndDisplayHistogram(data) {
    const sortOption = document.getElementById("sortOptions").value;
    let sortedData;

    switch (sortOption) {
        case "frequency-desc":
            sortedData = mergeSort(data, "frequency", false);
            break;
        case "frequency-asc":
            sortedData = mergeSort(data, "frequency", true);
            break;
        case "name-asc":
            sortedData = mergeSort(data, "name", true);
            break;
        case "name-desc":
            sortedData = mergeSort(data, "name", false);
            break;
        default:
            sortedData = data;
    }

    let output = "";
    sortedData.forEach(item => output += `${item.name} ${"*".repeat(item.frequency)}\n`);
    document.getElementById("histogramOutput").innerText = output;
}
