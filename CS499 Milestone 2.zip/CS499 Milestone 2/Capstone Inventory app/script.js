// Initialize an empty Map to store word frequencies
let itemMap = new Map();

// Function to process user input and count word frequencies
function processData() {
    let inputText = document.getElementById("inputData").value; // Get text input from the user
    let items = inputText.split(/\s+/); // Split input into words using spaces
    itemMap.clear(); // Clear previous data

    // Loop through words and count occurrences
    items.forEach(item => {
        if (item) { // Ignore empty strings
            itemMap.set(item, (itemMap.get(item) || 0) + 1); // Increment word count
        }
    });

    alert("Data processed successfully!"); // Notify user
}

// Function to display word frequencies in text format
function displayFrequencies() {
    let output = "";
    itemMap.forEach((value, key) => {
        output += `${key}: ${value}\n`; // Format output as "word: count"
    });
    document.getElementById("frequencyOutput").innerText = output; // Display in HTML
}

// Function to display a histogram using '*' symbols
function displayHistogram() {
    let output = "";
    itemMap.forEach((value, key) => {
        output += `${key} ${"*".repeat(value)}\n`; // Append '*' symbols based on count
    });
    document.getElementById("histogramOutput").innerText = output; // Display in HTML
}
