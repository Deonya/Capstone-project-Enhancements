// Initializes an empty Map to store word frequencies
let itemMap = new Map();

// fetch item data from JSON Server based on search
function fetchItemData() {
    const searchTerm = document.getElementById("inputData").value.trim().toLowerCase(); // Get the search term
    if (!searchTerm) {
        alert("Please enter an item to search for.");
        return;
    }

    fetch('http://localhost:3000/items')
        .then(response => response.json())
        .then(data => {
            const filteredData = data.filter(item => item.name.toLowerCase().includes(searchTerm));
            if (filteredData.length === 0) {
                alert("Item not found!");
            } else {
                displayItemData(filteredData); // Show data only for the searched item
            }
        })
        .catch(error => console.error('Error fetching data:', error));
}

// Function to display the item frequency
function displayItemData(data) {
    let output = "";
    data.forEach(item => {
        output += `${item.name}: ${item.frequency}\n`; // Display name and frequency
    });
    document.getElementById("frequencyOutput").innerText = output; // Display in HTML
}

// Function to process user input and count word frequencies
function processData() {
    let inputText = document.getElementById("inputData").value; // Get text input from the user
    let items = inputText.split(/\s+/); // Split input into words using spaces
    itemMap.clear(); // Clear previous data

    // Loop through words and count occurrences
    items.forEach(item => {
        if (item) { // Ignore empty strings
            itemMap.set(item, (itemMap.get(item) || 0) + 1); // Increment word count
        }
    });

    // After processing, adds these items to the database
    itemMap.forEach((value, key) => {
        saveItemData(key, value); // Save each processed item and frequency to the JSON Server
    });

    alert("Data processed and saved to server!"); // Notify user
}

// Function to save item data to JSON Server
function saveItemData(item, frequency) {
    fetch('http://localhost:3000/items', {
        method: 'POST',
        body: JSON.stringify({
            name: item,
            frequency: frequency
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        console.log('Data saved:', data);
    })
    .catch(error => console.error('Error saving data:', error));
}

// Function to display a histogram using '*' symbols
function displayHistogram() {
    let output = "";
    itemMap.forEach((value, key) => {
        output += `${key} ${"*".repeat(value)}\n`; // Append '*' symbols based on count
    });
    document.getElementById("histogramOutput").innerText = output; // Display in HTML
}
